declare module 'cors'
declare module 'express-rate-limit'
declare module 'express'
declare module 'mongoose'
declare module 'jsonwebtoken'
declare module 'axios'
declare module 'bcrypt'
declare module 'crypto'

// Allow importing .json files if needed
declare module '*.json'
